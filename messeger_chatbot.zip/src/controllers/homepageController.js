const getHomePage = (req, res) => {
    return res.render('homepage.ejs');
}

module.exports = {
     getHomePage
};